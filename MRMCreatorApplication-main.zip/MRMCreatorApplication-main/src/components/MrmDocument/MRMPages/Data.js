export const UserData = [
  {
    id: 1,
    year: 2016,
    profit: 15900,
    loss: 4000,
  },
  {
    id: 2,
    year: 2017,
    profit: 47600,
    loss: 40001,
  },
  {
    id: 3,
    year: 2018,
    profit: 22900,
    loss: 40010,
  },
  {
    id: 4,
    year: 2019,
    profit: 51900,
    loss: 200,
  },
  {
    id: 5,
    year: 2020,
    profit: 30900,
    loss: 5000,
  },
];
